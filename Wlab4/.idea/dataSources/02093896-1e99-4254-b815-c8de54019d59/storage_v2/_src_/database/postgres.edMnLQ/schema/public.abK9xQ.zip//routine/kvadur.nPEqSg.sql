create function kvadur(a integer, b integer, c integer) returns text
    immutable
    language plpgsql
as
$$
 DECLARE dis float; x1 float; x2 float;
 BEGIN
 SELECT b*b - 4*a*c into dis; select (-b + sqrt(dis))/2a into x1;
 select (-b - sqrt(dis))/2a into x2;
 return '' ||x1||' '||x2||'';
 END;
$$;

alter function kvadur(integer, integer, integer) owner to postgres;

